<?php
// Simple Rock-Paper-Scissors app (Oẳn tù tì)
$host = getenv('POSTGRES_HOST') ?: 'db';
$port = getenv('POSTGRES_PORT') ?: '5432';
$dbname = getenv('POSTGRES_DB') ?: 'rpsdb';
$user = getenv('POSTGRES_USER') ?: 'rps';
$pass = getenv('POSTGRES_PASSWORD') ?: 'rps_pass';
$dsn = "pgsql:host={$host};port={$port};dbname={$dbname}";

$pdo = null;
$dbError = null;
try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) {
    $dbError = $e->getMessage();
}

$choices = ['rock' => '✊', 'paper' => '✋', 'scissors' => '✌️'];
$outcome = null;
$player = null;
$computer = null;

function decide($p, $c) {
    if ($p === $c) return 'draw';
    if (($p === 'rock' && $c === 'scissors') || ($p === 'paper' && $c === 'rock') || ($p === 'scissors' && $c === 'paper')) return 'win';
    return 'lose';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['choice'])) {
    $player = $_POST['choice'];
    if (!array_key_exists($player, $choices)) $player = 'rock';
    $computer = array_rand($choices);
    $outcome = decide($player, $computer);

    if ($pdo) {
        $stmt = $pdo->prepare('INSERT INTO results (player_choice, computer_choice, outcome) VALUES (:p, :c, :o)');
        $stmt->execute([':p' => $player, ':c' => $computer, ':o' => $outcome]);
    }
}

$history = [];
if ($pdo) {
    $stmt = $pdo->query('SELECT id, player_choice, computer_choice, outcome, created_at FROM results ORDER BY id DESC LIMIT 10');
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Oẳn tù tì - LEPP Demo</title>
  <style>
    body{font-family: Arial, Helvetica, sans-serif;max-width:900px;margin:40px auto;padding:0 16px}
    h1{display:flex;align-items:center;gap:.5rem}
    .choices button{font-size:2rem;padding:.6rem 1rem;margin:.4rem}
    .result{margin-top:1rem;padding:1rem;border-radius:6px}
    .win{background:#d4edda;border:1px solid #c3e6cb}
    .lose{background:#f8d7da;border:1px solid #f5c6cb}
    .draw{background:#fff3cd;border:1px solid #ffeeba}
    table{width:100%;border-collapse:collapse;margin-top:1rem}
    th,td{padding:.5rem;border-bottom:1px solid #eee;text-align:left}
    .muted{color:#666;font-size:.9rem}
  </style>
</head>
<body>
  <h1>Oẳn tù tì <span class="muted">(rock-paper-scissors)</span></h1>

  <?php if ($dbError): ?>
    <p class="muted">Không kết nối được tới cơ sở dữ liệu: <?=htmlspecialchars($dbError)?>. Ứng dụng vẫn chạy cục bộ mà không lưu lịch sử.</p>
  <?php endif; ?>

  <form method="post">
    <div class="choices">
      <?php foreach ($choices as $key => $icon): ?>
        <button type="submit" name="choice" value="<?=htmlspecialchars($key)?>"><?=htmlspecialchars($icon)?> <div style="font-size:.5rem;display:inline-block;margin-left:.4rem"><?=htmlspecialchars($key)?></div></button>
      <?php endforeach; ?>
    </div>
  </form>

  <?php if ($outcome !== null): ?>
    <div class="result <?=htmlspecialchars($outcome)?>">
      <strong>Kết quả:</strong>
      Bạn <?=($outcome === 'win') ? 'thắng' : (($outcome === 'lose') ? 'thua' : 'hòa')?>!<br>
      Bạn: <?=htmlspecialchars($choices[$player])?> (<?=htmlspecialchars($player)?>) — Máy: <?=htmlspecialchars($choices[$computer])?> (<?=htmlspecialchars($computer)?>)
    </div>
  <?php endif; ?>

  <h2>Lịch sử (10 lượt gần nhất)</h2>
  <?php if (empty($history)): ?>
    <p class="muted">Không có dữ liệu lịch sử (hoặc chưa kết nối DB).</p>
  <?php else: ?>
    <table>
      <thead><tr><th>#</th><th>Bạn</th><th>Máy</th><th>Kết quả</th><th>Thời gian</th></tr></thead>
      <tbody>
        <?php foreach ($history as $row): ?>
          <tr>
            <td><?=htmlspecialchars($row['id'])?></td>
            <td><?=htmlspecialchars($choices[$row['player_choice']] ?? $row['player_choice'])?> <?=htmlspecialchars($row['player_choice'])?></td>
            <td><?=htmlspecialchars($choices[$row['computer_choice']] ?? $row['computer_choice'])?> <?=htmlspecialchars($row['computer_choice'])?></td>
            <td><?=htmlspecialchars($row['outcome'])?></td>
            <td><?=htmlspecialchars($row['created_at'])?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <footer style="margin-top:2rem" class="muted">Server: PHP + Nginx, DB: Postgres. Mở <a href="/">/</a> để chơi.</footer>
</body>
</html>
