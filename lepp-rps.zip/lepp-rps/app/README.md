Application folder for the LEPP RPS demo.

Public webroot: `public/` (contains `index.php`).

The Dockerfile builds a small PHP-FPM image with `pdo_pgsql` enabled so the app can talk to Postgres.
