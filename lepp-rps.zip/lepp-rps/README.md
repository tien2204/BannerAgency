LEPP Rock-Paper-Scissors (Oẳn tù tì) demo

This repository contains a minimal LEPP stack (Linux-like containers with Nginx, PHP-FPM, Postgres) using Docker Compose for a simple rock-paper-scissors game.

Quick start (Windows PowerShell):

```powershell
cd d:/ThucTapOE/lepp-rps
docker compose up --build
# or run in background
# docker compose up --build -d
```

Open http://localhost:8080 in your browser.

Stopping and cleanup:

```powershell
docker compose down -v
```

Notes:
- Database credentials are set in `docker-compose.yml` (user: rps / password: rps_pass / db: rpsdb).
- The Postgres DB initialization script is `db/init.sql` and will create the `results` table automatically on first startup.
- The PHP app expects the DB at service name `db` (Docker network created by compose).

If you want to customize ports or credentials, edit `docker-compose.yml`.

Enjoy!
